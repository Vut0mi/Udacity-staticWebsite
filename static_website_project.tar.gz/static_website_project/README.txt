Deploy Static Website on AWS


cloud front URL:

d2e3q9qrd12edl.cloudfront.net

static website URL :
http://my-475511349246-bucket.s3-website-us-east-1.amazonaws.com


